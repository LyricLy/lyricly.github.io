Edit by Dungeonfire: this is a modified version of BootCTR9. All credits go to their respective owners

This bootloader uses the same configuration as bootctr. 
If you use delebiles arm9loaderhax you can put the arm9loaderhax.bin file to the root of your 
sd-card, if you use my forks arm9loaderhax you only need to use the arm9bootloader.bin.
This bootloader defines which payload should be bootet by the key you press while powering on your 3DS.

Use github wiki to find out more about the usage:
https://github.com/hartmannaf/BootCtr9/wiki
